package sn.microkernel;

import java.util.ArrayList;

import org.junit.Test;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;

import sn.microkernel.components.ProcScheduler;

@RestClientTest
class ProcTest {

	

}
